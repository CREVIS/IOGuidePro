function gotoOnline() {
window.location.href = "http://www.hitachi-ds.com"
} 
